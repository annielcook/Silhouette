require(__dirname + '/applicationManager.ctrl.js')
