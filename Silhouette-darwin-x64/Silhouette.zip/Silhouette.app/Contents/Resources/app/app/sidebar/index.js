require(__dirname + '/sidebar.directive.js')
require(__dirname + '/installation.factory.js')