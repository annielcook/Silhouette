module.exports ={
    "AWSsecret" : "YyIakvXzuT+Nco0F4e+6+l0kVhof7wl8xCUzRE5V",
    "AWSbucket" : "silhouette.datastorage",
    "AWSKey" : "AKIAIR3AHFWLCKNNHGRQ"
}
